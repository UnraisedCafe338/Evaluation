<!DOCTYPE html>
<html lang="en">
<head>
  <!-- Head content -->
</head>
<body>
<?php include 'sidebar.php'; ?>
<div class="content">
  <h1>Manage Criteria</h1>
  <?php
  // Check if a criteria ID is provided
  if (isset($_GET['criteria_id'])) {
    $criteria_id = $_GET['criteria_id'];
    // Fetch criteria details from the database
    $host = 'localhost';
    $dbname = 'evaluation_quiet';
    $user = 'admin';
    $pass = 'admin';  
    $connection = mysqli_connect($host, $user, $pass, $dbname);
    if ($connection) {
      $query = "SELECT * FROM criteria WHERE criteria_id = $criteria_id";
      $result = mysqli_query($connection, $query);
      if ($row = mysqli_fetch_assoc($result)) {
        echo "<h2>Managing Questions for: {$row['criteria_name']}</h2>"; // Displaying the criteria name
        
        // Display the list of questions related to this criteria
        echo "<h3>Question List</h3>";
        $query_questions = "SELECT * FROM question_list WHERE criteria_id = $criteria_id";
        $result_questions = mysqli_query($connection, $query_questions);
        if (mysqli_num_rows($result_questions) > 0) {
          echo "<ul>";
          while ($row_question = mysqli_fetch_assoc($result_questions)) {
            echo "<li>{$row_question['question_text']}</li>";
          }
          echo "</ul>";
        } else {
          echo "<p>No questions found for this criteria.</p>";
        }
        
        // Include forms for managing questions related to this criteria
        // You can include forms for adding/editing/deleting questions here
      } else {
        echo "<p>Criteria not found.</p>";
      }
      mysqli_close($connection);
    } else {
      echo "<p>Failed to connect to the database.</p>";
    }
  } else {
    echo "<p>No criteria selected.</p>";
  }
  ?>
</div>
</body>
</html>
