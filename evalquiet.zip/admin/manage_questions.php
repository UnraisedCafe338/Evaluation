<?php

$host = 'localhost';
$dbname = 'evaluation_quiet';
$user = 'admin';
$pass = 'admin';

// Create connection
$connection = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_criteria_name'])) {
    // Validate and sanitize the input
    $edited_criteria_name = mysqli_real_escape_string($connection, $_POST['edit_criteria_name']);
    $criteria_id = $_POST['criteria_id'];
    
    // Update the criteria name in the database
    $update_query = "UPDATE criteria SET criteria_name = '$edited_criteria_name' WHERE criteria_id = $criteria_id";
    
    if ($connection->query($update_query) === TRUE) {
        echo "Criteria name updated successfully.";
    } else {
        echo "Error updating criteria name: " . $connection->error;
    }
}

// Close connection
$connection->close();

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Evaluation Question Management</title>
  <link rel="stylesheet" href="styles.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <style>
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 30px;
      table-layout: fixed;
    }
    th, td {
      border: 1px solid #ddd;
      padding: 8px;
    }
    th {
      background-color: #f2f2f2;
    }
    tr:hover {
      background-color: #f2f2f2;
    }
    /* Adjust the width of the ID column */
tr > td.id-column { /* Assuming the ID column is the first column */
  width: 10% !important; /* Adjust the width as needed */
}
    .edit-delete-btns {
      text-align: right;
    }
    .edit-delete-form {
      display: none;
    }
    .expand-input {
  width: 10%; /* Set initial width */
  height: 30%;
  box-sizing: border-box; /* Include padding and border in the width */

}

/* Optional: Add padding to the input fields for better appearance */
.expand-input {
  padding: 8px; /* Adjust padding as needed */
}
.addQuestion {
  background: linear-gradient(to bottom, rgb(66, 78, 255), rgb(49, 0, 208));
  width: 3000px;
  padding: 10px;
  position: fixed;
  margin-top: -30px;
  margin-left: -19px;
  color: white;
  bottom: 0px;
}
.addQuestion::before {
    content: "";
    position: fixed;
    left: 50%;
    transform: translateX(-50%) translateY(-50%);
    width: 3000px;
    height: 3px;
    background-color: #ffee00;
    margin-bottom: 300px;
  }
  .question-button {
    background-color: darkblue;
    min-width: 120px; /* Set a minimum width */
    margin-right: 0px; /* Add margin to position it */
    margin-left: -10px;
    padding-left: 15px;
    border-radius: 10px;
  }
  .content {
    margin-left: 240px;
    margin-bottom: 100px;
    padding: 20px;
    z-index: 0;
    }
    .back-button {
    background-color: #0055ff;
    color: rgb(255, 255, 255);
    padding: 10px 5px;
    border: none;
    cursor: pointer;
    border-radius: 5px;
    text-decoration: none;
    position: fixed;
    height: 15px;
  }
  .back-button:hover {
    background-color: #0026d0f8;
    
  }
  
</style>

  <script>
    // JavaScript function to show/hide edit form when edit button is clicked
    function toggleEditForm(questionID) {
      var editForm = document.getElementById('edit_delete_form_' + questionID);
      if (editForm.style.display === 'none') {
        editForm.style.display = 'block';
      } else {
        editForm.style.display = 'none';
      }
    }

    // JavaScript function to automatically reload the page after editing
    function reloadPage() {
      setTimeout(function() {
        location.reload();
      }, 1000); // Reload after 1 second (1000 milliseconds)
    }
    
    // JavaScript function to close the edit form
    function closeEditForm(questionID) {
      var editForm = document.getElementById('edit_delete_form_' + questionID);
      editForm.style.display = 'none';
      reloadPage(); // Reload the page after closing the edit form
    }
    // JavaScript function to adjust input field size dynamically
document.addEventListener('input', function (event) {
  if (event.target.classList.contains('expand-input')) {
    event.target.style.width = 'auto'; // Reset width to auto to measure content size
    event.target.style.width = (event.target.scrollWidth + 5) + 'px'; // Add a small buffer
  }
});

  </script>
</head>
<body>
  
<?php include 'sidebar.php'; ?>
<div class="content">
  <h1>Evaluation Question Management</h1><br><br><br>

  
  
  <table>
    <thead>
      <tr>
        
      </tr>
    </thead>
    <tbody>
<?php
    
  // Check if a criteria ID is provided
  if (isset($_GET['criteria_id'])) {
    $criteria_id = $_GET['criteria_id'];
    // Fetch criteria details from the database
    $host = 'localhost';
    $dbname = 'evaluation_quiet';
    $user = 'admin';
    $pass = 'admin';  
    $connection = mysqli_connect($host, $user, $pass, $dbname);
    if ($connection) {
      
      $query = "SELECT * FROM criteria WHERE criteria_id = $criteria_id";
      $result = mysqli_query($connection, $query);



      if ($row = mysqli_fetch_assoc($result)) {
        echo "<h2 id=\"criteria_name\">Managing Questions for Criteria: <span id=\"editable_criteria_name\">{$row['criteria_name']}</span> <button onclick=\"toggleEditCriteriaName()\"><i class=\"fa fa-edit\"></i></button></h2>"; // Displaying the criteria name
        echo "<a href='criteria_list.php' class='back-button'>Back to Criteria List</a>";
        // Display the list of questions related to this criteria
        echo "<h3>Question List</h3>";
        $query_questions = "SELECT question_id, question_text FROM question_list WHERE criteria_id = $criteria_id";
        $result_questions = mysqli_query($connection, $query_questions);
        if (mysqli_num_rows($result_questions) > 0) {
          echo "<table>";
          echo "<thead><tr><th>Question no.</th><th>Questions</th><th>Actions</th></tr></thead>";
          echo "<tbody>";
          $rowCount = 1;
          while ($row_question = mysqli_fetch_assoc($result_questions)) {
            echo "<tr>";
            echo "<td>{$rowCount}</td>"; 
            echo "<td>{$row_question['question_text']}</td>";
            echo "<td class='edit-delete-btns'>";
            echo "<button onclick='toggleEditForm({$row_question['question_id']})'><i class='fa fa-tasks'>&nbsp;</i></button>";
            echo "</td>";
            echo "</tr>";
            echo "<tr class='edit-delete-form' id='edit_delete_form_{$row_question['question_id']}'>";
            echo "<td colspan='3'>";
            echo "<form action='edit_delete_question.php' method='POST'>";
            echo "<input type='hidden' name='question_id' value='{$row_question['question_id']}'>";
            echo "<input type='text' name='edited_question' placeholder='Edited Question' class='expand-input' required>";
            echo "&nbsp&nbsp&nbsp<button type='submit' name='action' value='edit' onclick='reloadPage()'><i class='fa fa-edit'>&nbsp;Edit</i></button>&nbsp&nbsp&nbsp";
            echo "<button type='submit' name='action' value='delete' onclick='reloadPage()'><i class='fa fa-trash'>&nbsp;Delete</i></button>";
            echo "<input type='hidden' name='criteria_id' value='{$criteria_id}'>";
            echo "</form>";
            echo "</td>";
            echo "</tr>";
            $rowCount++; 
          }
          echo "</tbody>";
          echo "</table>";
        } else {
          echo "<p>No questions found for this criteria.</p>";
        }

        // Add a button to go back to criteria_list.php
        echo "";
      } else {
        echo "<p>Criteria not found.</p>";
      }
      mysqli_close($connection);
    } else {
      echo "<p>Failed to connect to the database.</p>";
    }
  } else {
    echo "<p>No criteria selected.</p>";
  }
  ?>


    </tbody>
  </table>

<div class="addQuestion">
  <h3>Add New Question</h3>
<form action="add_question.php" method="POST">
  <label for="new_question">New Question:</label>
  <input type="text" id="new_question" name="new_question" required class="expand-input"><br><br>
  <button type="submit">Add Question</button>
  <input type="hidden" name="criteria_id" value="<?php echo $criteria_id; ?>">&nbsp;&nbsp;&nbsp;
  

</form>
</div>
</div>
</body>
<script>
  function toggleEditCriteriaName() {
    var editableCriteriaName = document.getElementById('editable_criteria_name');
    var criteriaNameInput = document.createElement('input');
    criteriaNameInput.setAttribute('type', 'text');
    criteriaNameInput.setAttribute('id', 'criteria_name_input');
    criteriaNameInput.setAttribute('value', editableCriteriaName.textContent);
    criteriaNameInput.classList.add('expand-input');
    editableCriteriaName.parentNode.replaceChild(criteriaNameInput, editableCriteriaName);
    var editButton = document.querySelector('button[onclick="toggleEditCriteriaName()"]');
    editButton.innerHTML = '<i class="fa fa-check"></i>';
    editButton.setAttribute('onclick', 'updateCriteriaName()');
    criteriaNameInput.focus();
  }

  function updateCriteriaName() {
    var criteriaNameInput = document.getElementById('criteria_name_input');
    var newCriteriaName = criteriaNameInput.value;
    var criteriaId = <?php echo $criteria_id; ?>; // Assuming $criteria_id is available in the PHP context
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "update_criteria_name.php", true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
    xhr.onreadystatechange = function() {
      if (xhr.readyState == 4 && xhr.status == 200) {
        var editableCriteriaName = document.createElement('span');
        editableCriteriaName.setAttribute('id', 'editable_criteria_name');
        editableCriteriaName.textContent = newCriteriaName;
        criteriaNameInput.parentNode.replaceChild(editableCriteriaName, criteriaNameInput);
        var editButton = document.querySelector('button[onclick="updateCriteriaName()"]');
        editButton.innerHTML = '<i class="fa fa-edit"></i>';
        editButton.setAttribute('onclick', 'toggleEditCriteriaName()');
      }
    };
    xhr.send("edited_criteria_name=" + newCriteriaName + "&criteria_id=" + criteriaId);
  }
</script>


</html>
