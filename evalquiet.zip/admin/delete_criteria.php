<?php

$host = 'localhost';
$dbname = 'evaluation_quiet';
$user = 'admin';
$pass = 'admin';

// Create connection
$connection = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Check if action and criteria_id are provided
if (isset($_GET['action']) && isset($_GET['criteria_id'])) {
    $action = $_GET['action'];
    $criteria_id = $_GET['criteria_id'];

    // If action is delete
    if ($action === 'delete') {
        // Delete related records in the question_list table first
        $delete_questions_query = "DELETE FROM question_list WHERE criteria_id = $criteria_id";
        $result_delete_questions = $connection->query($delete_questions_query);
        
        // Then delete the criteria
        $delete_criteria_query = "DELETE FROM criteria WHERE criteria_id = $criteria_id";
        $result_delete_criteria = $connection->query($delete_criteria_query);

        if ($result_delete_criteria) {
            // Reset auto-increment value after deletion
            $reset_query = "ALTER TABLE criteria AUTO_INCREMENT = 1";
            $connection->query($reset_query);
            
            echo "Criteria deleted successfully.";
            header("Location: criteria_list.php");
        } else {
            echo "Error deleting criteria: " . $connection->error;
        }
    } else {
        echo "Invalid action.";
    }
} else {
    echo "Invalid action or criteria ID.";
}

// Close connection
$connection->close();

?>
