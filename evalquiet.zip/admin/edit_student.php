<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Edit Student</title>
    <!-- Include any necessary CSS files -->
    <link rel="stylesheet" href="styles.css">
</head>
<style>
    .below-title{
  background: linear-gradient(to top, rgb(66, 78, 255), rgb(49, 0, 208));
  width: 3000px;
  padding: 20px;
  position: fixed;
  margin-top: 35px;
  margin-left: -19px;
  color: white;
  top: 30px;
  border-bottom: 3px solid #002594; 
}
.students-button {
    background-color: darkblue;
    min-width: 120px; 
    margin-right: 0px;
    margin-left: -10px;
    padding-left: 15px;
    border-radius: 10px;
}
.success {
    color: goldenrod;
}

</style>

<body>
<?php include 'sidebar.php'; ?>
<div class="content">
<h1>Student Management</h1><br><h2 class="below-title">⇛ Manage Student<h2><br><br><br><br>
<?php
// Include your database connection file if necessary
// Include 'sidebar.php' or navigation if needed

// Check if student ID is provided in the URL
if(isset($_GET['student_ID'])) {
    $studentID = $_GET['student_ID'];
    
    // Fetch student details from the database based on studentID
    $host = 'localhost';
    $dbname = 'evaluation_quiet';
    $user = 'admin';
    $pass = 'admin';  
    
    $connection = mysqli_connect($host, $user, $pass, $dbname);
    if ($connection) {
        $query = "SELECT * FROM student_info WHERE student_ID = '$studentID'";

        $result = mysqli_query($connection, $query);
        
        if(mysqli_num_rows($result) > 0) {
            $student = mysqli_fetch_assoc($result); // Fetch student details
        } else {
            echo "No student found with ID: $studentID";
            exit();
        }

        // Check if the form is submitted
        if(isset($_POST['submit'])) {
            // Retrieve form data
            $studentID = $_POST['student_ID']; // Added line to get student ID
            $newStudentId = $_POST['new_id'];
            $newName = $_POST['new_name'];
            $newCourse = $_POST['new_course'];
            $newSection = $_POST['new_section'];
        
            // Update student information in the database
            $updateQuery = "UPDATE student_info SET student_ID = '$newStudentId', student_NAME = '$newName', student_COURSE = '$newCourse', student_SECTION = '$newSection' WHERE student_ID = '$studentID'";
            $updateResult = mysqli_query($connection, $updateQuery);
        
            if($updateResult) {
                echo "<h3 class='success'>Student information updated successfully.</h3>";
                // Optionally, you can redirect the user to another page after successful update
            } else {
                echo "Error updating student information: " . mysqli_error($connection);
            }
        }
        


        // Close the database connection
        mysqli_close($connection);
    } else {
        echo "Failed to connect to the database.";
        exit();
    }
} else {
    echo "Student ID not provided.";
    exit();
}
?>

<div class="edit-student-form">
    <form action="" method="POST">
    <input type="hidden" name="student_ID" value="<?php echo $student['student_ID']; ?>">
        <label for="new_id">Student ID:</label>
        <input type="text" id="new_id" name="new_id" value="<?php echo $student['student_ID']; ?>" required>
        
        
        <label for="new_name">Name:</label>
        <input type="text" id="new_name" name="new_name" value="<?php echo $student['student_NAME']; ?>" required>
        
        <label for="new_course">Course:</label>
        <input type="text" id="new_course" name="new_course" value="<?php echo $student['student_COURSE']; ?>" required>
        
        <label for="new_section">Section:</label>
        <input type="text" id="new_section" name="new_section" value="<?php echo $student['student_SECTION']; ?>" required>
        
        <button type="submit" name="submit">Update</button>
    </form>
    <form action="student_list.php">
    <button type="submit" name="submit">Back</button>
    </form>
</div>



</div>
</body>
</html>
