<?php
// update_criteria_name.php

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edited_criteria_name'], $_POST['criteria_id'])) {
    // Connect to the database
    $host = 'localhost';
    $dbname = 'evaluation_quiet';
    $user = 'admin';
    $pass = 'admin';
    
    $connection = new mysqli($host, $user, $pass, $dbname);

    // Check connection
    if ($connection->connect_error) {
        die("Connection failed: " . $connection->connect_error);
    }

    // Validate and sanitize the input
    $edited_criteria_name = mysqli_real_escape_string($connection, $_POST['edited_criteria_name']);
    $criteria_id = $_POST['criteria_id'];
    
    // Update the criteria name in the database
    $update_query = "UPDATE criteria SET criteria_name = '$edited_criteria_name' WHERE criteria_id = $criteria_id";
    
    if ($connection->query($update_query) === TRUE) {
        echo "Criteria name updated successfully.";
    } else {
        echo "Error updating criteria name: " . $connection->error;
    }

    // Close connection
    $connection->close();
} else {
    echo "Invalid request.";
}
?>
