<?php

$host = 'localhost';
$dbname = 'evaluation_quiet';
$user = 'admin';
$pass = 'admin';

// Create connection
$connection = new mysqli($host, $user, $pass, $dbname);

// Check connection
if ($connection->connect_error) {
    die("Connection failed: " . $connection->connect_error);
}

// Check if the form has been submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize the input
    $new_criteria_name = mysqli_real_escape_string($connection, $_POST['new_criteria_name']);
    
    // Insert the new criteria into the database
    $insert_query = "INSERT INTO criteria (criteria_name) VALUES ('$new_criteria_name')";
    
    if ($connection->query($insert_query) === TRUE) {
        // Reset the auto-increment value
        $reset_query = "SET @new_id := 0; UPDATE criteria SET criteria_id = @new_id := @new_id + 1";
        if ($connection->multi_query($reset_query) === TRUE) {
            echo "New criteria created successfully.";
            header("Location: criteria_list.php");
        } else {
            echo "Error resetting auto-increment value: " . $connection->error;
        }
    } else {
        echo "Error creating criteria: " . $connection->error;
    }
}

// Close connection
$connection->close();

?>
