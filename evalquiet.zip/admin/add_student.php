<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $host = 'localhost';
    $dbname = 'evaluation_quiet';
    $user = 'admin';
    $pass = 'admin';

    $connection = mysqli_connect($host, $user, $pass, $dbname);

    if (!$connection) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $studentID = $_POST['student_id'];
    $name = $_POST['new_name'];
    $course = $_POST['new_course'];
    $section = $_POST['new_section'];
    $evaluated = isset($_POST['evaluated_checkbox']) ? 1 : 0;
    $regular = isset($_POST['regular_checkbox']) ? 1 : 0;

    $studentID = mysqli_real_escape_string($connection, $studentID);
    $name = mysqli_real_escape_string($connection, $name);
    $course = mysqli_real_escape_string($connection, $course);
    $section = mysqli_real_escape_string($connection, $section);

    // Adds the new student by admin into the database
    $query = "INSERT INTO student_info (student_ID, student_NAME, student_COURSE, student_SECTION, evaluated, regular_student) VALUES ('$studentID', '$name', '$course', '$section', $evaluated, $regular)";
    if (mysqli_query($connection, $query)) {
        echo "New student added successfully";
    } else {
        echo "Error adding student: " . mysqli_error($connection);
    }

   
    mysqli_close($connection);
} else {
   
    echo "Error: Invalid request";
}
header("Location: student_list.php");
    exit(); 
?>
