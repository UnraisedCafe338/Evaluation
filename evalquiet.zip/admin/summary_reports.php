<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Dashboard Design</title>
  <link rel="stylesheet" href="styles.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>


<style>
  .summary-button {
    background-color: darkblue;
    min-width: 120px; 
    margin-right: 0px;
    margin-left: -10px;
    padding-left: 15px;
    border-radius: 10px;
}
</style>

<body>
<?php include 'sidebar.php'; ?>
  <div class="content">
    <h1>SUMMARY REPORTS</h1><br><br><br><br>
    <h3>hello</h3>
    </table>
  </div>
  
</body>
</html>
