<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Student Management</title>
  <link rel="stylesheet" href="styles.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
  <style>
    /* Add or modify styles as needed */
    .content {
      margin-left: 240px;
      margin-bottom: 100px;
      padding: 20px;
      z-index: 0;
    }
    table {
      width: 150%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }
    th, td {
      padding: 10px;
      border: 1px solid #ddd;
      text-align: left;
    }
    th {
      background-color: #f2f2f2;
    }
    .actions-col {
      width: 150px;
      text-align: center;
    }
    .menu-btn {
      cursor: pointer;
      display: inline-block;
      padding: 5px;
    }
    .edit-delete-btns {
      display: inline-block;
    }
    .edit-delete-btns button {
      background-color: transparent;
      border: none;
      cursor: pointer;
      font-size: 14px; /* Adjust font size */
    }
    .edit-delete-btns button.delete-btn {
      color: red;
    }
    .edit-delete-btns button.delete-btn:hover {
      color: darkred; /* Change color on hover */
    }
    .students-button {
      background-color: darkblue;
      min-width: 120px; 
      margin-right: 0px;
      margin-left: -10px;
      padding-left: 15px;
      border-radius: 10px;
    }
    .content-addstud {
      background: linear-gradient(to bottom, rgb(66, 78, 255), rgb(49, 0, 208));
      width: 3000px;
      padding: 10px;
      position: fixed;
      margin-top: -30px;
      margin-left: -19px;
      color: white;
      bottom: 0px;
      border-top: 2px solid rgb(23, 0, 116);
    }
    .content-addstud::before {
      content: "";
      position: fixed;
      left: 50%;
      transform: translateX(-50%) translateY(-50%);
      width: 3000px;
      height: 3px;
      background-color: #ffee00;
      margin-bottom: 300px;
    }
    .search-container {
      background: linear-gradient(to top, rgb(66, 78, 255), rgb(49, 0, 208));
      width: 3000px;
      padding: 20px;
      position: fixed;
      margin-top: -30px;
      margin-left: -19px;
      color: white;
      top: 100px;
      border-bottom: 2px solid rgb(23, 0, 116);
    }
    .search-container::after {
      content: "";
      position: fixed;
      left: 50%;
      top: 130px;
      transform: translateX(-50%) translateY(-50%);
      width: 3000px;
      height: 5px;
      background-color: #ffee00;
      margin-bottom: 100px;
    }
    .add-student-popup {
      display: none;
      position: fixed;
      left: 50%;
      top: 50%;
      transform: translate(-50%, -50%);
      background-color: white;
      padding: 20px;
      border-radius: 5px;
      box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.5);
    }
    .overlay2 {
      display: none;
      position: fixed;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, 0.5);
    }
    /* CSS for the close button */
.close-btn {
  position: absolute;
  top: 10px;
  right: 10px;
  cursor: pointer;
  font-size: 20px;
  color: #aaa;
}

.close-btn:hover {
  color: #000; /* Change color on hover */
}

  </style>
</head>
<body>
  
<?php include 'sidebar.php'; ?>
<div class="content">
  <h1>Student Management</h1><br><br><br><br>
  <div class="search-container">
  
    <input type="text" id="searchInput" onkeyup="searchTable()" placeholder="Search for student...">
    <select id="courseFilter" onchange="filterByCourse()">
      <option value="">All Courses</option>
      <option value="BSIS">BSIS</option>
      <option value="BSTM">BSTM</option>
      <option value="BSMA">BSMA</option>
      <!-- Add more options for other courses if needed -->
    </select>
    <button class="addstudbutton" onclick="toggleAddStudentPopup()">Add New Student</button>
  </div>

  <!-- Display existing students from the database -->
  <h3>Student List</h3>
  <table id="studentTable">
    <thead>
      <tr>
        <th>Student ID</th>
        <th>Name</th>
        <th>Course</th>
        <th>Section</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php
        $host = 'localhost';  
        $dbname = 'evaluation_quiet';
        $user = 'admin'; 
        $pass = 'admin'; 
        $connection = mysqli_connect($host, $user, $pass, $dbname);
        if ($connection) {
          $query = "SELECT * FROM student_info";
          $result = mysqli_query($connection, $query);
          if (mysqli_num_rows($result) > 0) {
            echo "<form method='post' action='edit_student.php'>"; // Open the form tag here
            while ($row = mysqli_fetch_assoc($result)) {
              echo "<tr>";
              echo "<td>{$row['student_ID']}</td>";
              echo "<td data-editable='true' data-student-id='{$row['student_ID']}' data-column-name='student_NAME'>{$row['student_NAME']}</td>";
              echo "<td data-editable='true' data-student-id='{$row['student_ID']}' data-column-name='student_COURSE'>{$row['student_COURSE']}</td>";
              echo "<td data-editable='true' data-student-id='{$row['student_ID']}' data-column-name='student_SECTION'>{$row['student_SECTION']}</td>";
              echo "<td class='actions-col'>";
              // Add a button to redirect to the edit page of the selected student
              echo "<a href='edit_student.php?student_ID={$row['student_ID']}' class='button'><i class='fas fa-tasks'></i> MANAGE</a>&nbsp;&nbsp;&nbsp;";
              // Add delete button
              echo "<button class='edit-delete-btns delete-btn' onclick='deleteStudent({$row['student_ID']})'><i class='fas fa-trash'></i></button>";
              echo "</td>";
              echo "</tr>";
            }
            echo "</form>"; // Close the form tag here
          } else {
            echo "<tr><td colspan='5'>No students found.</td></tr>";
          }
          mysqli_close($connection);
        } else {
          echo "<tr><td colspan='5'>Failed to connect to the database.</td></tr>";
        }
      ?>
    </tbody>
  </table>

  <div class="overlay2" id="overlay2"></div>
  <div class="add-student-popup" id="addStudentPopup">
  <span class="close-btn" onclick="toggleAddStudentPopup()">&times;</span>
  <h3>Add New Student</h3>
  <form action="add_student.php" method="POST">
    <label for="student_id">Student ID:</label>
    <input type="text" id="student_id" name="student_id" required class="expand-input">
    <label for="new_name">Name:</label>
    <input type="text" id="new_name" name="new_name" required class="expand-input">
    <label for="new_course">Course:</label>
    <input type="text" id="new_course" name="new_course" required class="expand-input">
    <label for="new_section">Section:</label>
    <input type="text" id="new_section" name="new_section" required class="expand-input"><br><br><br>

    <button type="submit">Add Student</button>
  </form>
</div>

  
</div>
<script>
  // Function to edit a student
  function editStudent(studentID) {
    var newName = document.querySelector('td[data-student-id="' + studentID + '"][data-column-name="student_NAME"]').textContent.trim();
    var newCourse = document.querySelector('td[data-student-id="' + studentID + '"][data-column-name="student_COURSE"]').textContent.trim();
    var newSection = document.querySelector('td[data-student-id="' + studentID + '"][data-column-name="student_SECTION"]').textContent.trim();

    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'edit_delete_student.php', true);
    xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
    xhr.onload = function() {
      if (xhr.status === 200) {
        reloadPage(); // Reload the page after successful editing
      } else {
        console.error('Error editing student:', xhr.responseText);
      }
    };
    xhr.onerror = function() {
      console.error('Network error occurred while editing student');
    };
    xhr.send('action=edit&student_ID=' + studentID + '&edited_name=' + newName + '&edited_course=' + newCourse + '&edited_section=' + newSection);
  }

  // Function to delete a student
  function deleteStudent(studentID) {
    if (confirm("Are you sure you want to delete this student?")) {
      var xhr = new XMLHttpRequest();
      xhr.open('POST', 'delete_student.php', true);
      xhr.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
      xhr.onload = function() {
        if (xhr.status === 200) {
          reloadPage(); // Reload the page after successful deletion
        } else {
          console.error('Error deleting student:', xhr.responseText); 
        }
      };
      xhr.onerror = function() {
        console.error('Network error occurred while deleting student'); 
      };
      xhr.send('student_ID=' + studentID);
    }
  }

  // Function to toggle the visibility of edit and delete buttons
  function toggleMenu(button) {
    var menu = button.nextElementSibling;
    menu.style.display = menu.style.display === "none" ? "inline-block" : "none";
  }

  // Function to reload the page
  function reloadPage() {
    window.location.reload();
  }

  // Function to search table based on input
  function searchTable() {
    var input, filter, table, tr, td, i, txtValue;
    input = document.getElementById("searchInput");
    filter = input.value.toUpperCase();
    table = document.getElementById("studentTable");
    tr = table.getElementsByTagName("tr");

    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[1]; // Assuming name is in the second column
      if (td) {
        txtValue = td.textContent || td.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }
    }
  }

  // Function to filter table by course
  function filterByCourse() {
    var courseSelect, selectedCourse, table, tr, td, i;
    courseSelect = document.getElementById("courseFilter");
    selectedCourse = courseSelect.value.toUpperCase();
    table = document.getElementById("studentTable");
    tr = table.getElementsByTagName("tr");

    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[2]; // Assuming course is in the third column
      if (td) {
        if (selectedCourse === "" || td.textContent.toUpperCase() === selectedCourse) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }
    }
  }

  // Function to toggle the visibility of the add student popup
  function toggleAddStudentPopup() {
    var popup = document.getElementById("addStudentPopup");
    var overlay = document.getElementById("overlay2");
    if (popup.style.display === "none" || popup.style.display === "") {
      popup.style.display = "block";
      overlay.style.display = "block";
    } else {
      popup.style.display = "none";
      overlay.style.display = "none";
    }
  }
</script>
</body>
</html>
