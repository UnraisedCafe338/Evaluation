<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>Evaluation Question Management</title>
<link rel="stylesheet" href="styles.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

<style>
/* Button styles */
.button {
  background-color: #0055ff;
    color: rgb(255, 255, 255);
    padding: 10px 20px;
    border: none;
    cursor: pointer;
    border-radius: 5px;
}

.button:hover {
  background-color: navy;
}

/* Table styles */
table {
  width: 100%;
  border-collapse: collapse;
  table-layout: fixed;
}

th, td {
  border: 1px solid #ddd;
  padding: 8px;
  text-align: center;
}

th {
  background-color: #f2f2f2;
}

tr:hover {
  background-color: #f2f2f2;
}
.question-button {
    background-color: darkblue;
    min-width: 120px; /* Set a minimum width */
    margin-right: 0px; /* Add margin to position it */
    margin-left: -10px;
    padding-left: 15px;
    border-radius: 10px;
  }
</style>
</head>
<body>
<?php include 'sidebar.php'; ?>
<div class="content">
  <h1>Criteria Management</h1>
  <h3>Criteria List</h3>
  <table>
    <thead>
      <tr>
        <th>Criteria No.</th>
        <th>Criteria Name</th>
        <th>Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php
      // Fetch criteria from the database and display them
      $host = 'localhost';
      $dbname = 'evaluation_quiet';
      $user = 'admin';
      $pass = 'admin';  
      $connection = mysqli_connect($host, $user, $pass, $dbname);
      if ($connection) {
        $query = "SELECT * FROM criteria";
        $result = mysqli_query($connection, $query);
        $rowCount = 1;
        while ($row = mysqli_fetch_assoc($result)) {
          echo "<tr>";
          echo "<td>{$rowCount}</td>"; 
          echo "<td>{$row['criteria_name']}</td>";
          echo "<td>";
          echo "<a href='manage_questions.php?criteria_id={$row['criteria_id']}' class='button'><i class='fas fa-tasks'></i></a>&nbsp;&nbsp&nbsp;";
          echo "<a href='delete_criteria.php?action=delete&criteria_id={$row['criteria_id']}' class='button'><i class='fas fa-trash'></i></a>";
          echo "</td>";
          echo "</tr>";
          $rowCount++;
        }
        mysqli_close($connection);
      } else {
        echo "<tr><td colspan='2'>Failed to connect to the database.</td></tr>";
      }
      ?>
    </tbody>
  </table>
  <h3>Create New Criteria</h3>
  <form action="create_criteria.php" method="POST">
    <label for="new_criteria_name">Criteria Name:</label>
    <input type="text" id="new_criteria_name" name="new_criteria_name" required>
    <!-- Add any additional fields for criteria creation if needed -->
    <button type="submit">Create Criteria</button>
  </form>
</div>
</body>
</html>
