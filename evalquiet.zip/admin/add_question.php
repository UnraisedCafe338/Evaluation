<?php

$host = 'localhost';
$dbname = 'evaluation_quiet';
$user = 'admin';
$pass = 'admin';

$connection = mysqli_connect($host, $user, $pass, $dbname);
if (!$connection) {
    echo "Failed to connect to the database.";
    exit(); 
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    $newQuestion = mysqli_real_escape_string($connection, $_POST['new_question']);
    $criteriaID = mysqli_real_escape_string($connection, $_POST['criteria_id']); // Add this line to get the criteria ID
    
    // Inserts new question added into the database
    $query = "INSERT INTO question_list (question_text, criteria_id) VALUES ('$newQuestion', '$criteriaID')"; // Include criteria ID in the query
    $result = mysqli_query($connection, $query);

    if ($result) {
        // Reset the auto-increment value after successful insertion
        $resetQuery1 = "SET @new_id := 0";
        $resetResult1 = mysqli_query($connection, $resetQuery1);
    
        if ($resetResult1) {
            $resetQuery2 = "UPDATE question_list SET question_id = @new_id := @new_id + 1 ORDER BY question_id";
            $resetResult2 = mysqli_query($connection, $resetQuery2);
    
            if ($resetResult2) {
                // Refreshes back to the manage questions page with the criteria ID
                header("Location: manage_questions.php?criteria_id=$criteriaID");
                exit(); 
            } else {
                // Handle error if reset query 2 fails
                echo "Error resetting auto-increment value.";
            }
        } else {
            // Handle error if reset query 1 fails
            echo "Error resetting auto-increment value.";
        }
    } else {
        // Handle error if insertion fails
        error_log("Error adding new question: " . mysqli_error($connection));
        echo "An error occurred while processing your request. Please try again later.";
    }
}
?>
