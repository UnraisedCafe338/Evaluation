<?php
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action'])) {
    $host = 'localhost';
    $dbname = 'evaluation_quiet';
    $user = 'admin';
    $pass = 'admin';

    $connection = mysqli_connect($host, $user, $pass, $dbname);

    if (!$connection) {
        die("Connection failed: " . mysqli_connect_error());
    }

    switch ($_POST['action']) {
        case 'edit':
            // Validate and sanitize input data
            $studentID = mysqli_real_escape_string($connection, $_POST['student_ID']);
            $editedName = mysqli_real_escape_string($connection, $_POST['edited_name']);
            $editedCourse = mysqli_real_escape_string($connection, $_POST['edited_course']);
            $editedSection = mysqli_real_escape_string($connection, $_POST['edited_section']);
            $evaluated = isset($_POST['edited_evaluated']) ? 1 : 0;
            $regular = isset($_POST['edited_regular']) ? 1 : 0;

            // Update student information in the database
            $query = "UPDATE student_info SET student_NAME=?, student_COURSE=?, student_SECTION=?, evaluated=?, regular_student=? WHERE student_ID=?";

            $stmt = mysqli_prepare($connection, $query);

            // Bind parameters to the prepared statement
            mysqli_stmt_bind_param($stmt, "sssiii", $editedName, $editedCourse, $editedSection, $evaluated, $regular, $studentID);

            // Execute the prepared statement
            if (mysqli_stmt_execute($stmt)) {
                echo "Student information updated successfully";
            } else {
                echo "Error updating student information: " . mysqli_error($connection);
            }

            mysqli_stmt_close($stmt);
            break;

            case 'delete':
                $studentID = $_POST['student_ID'];
    
                // Set foreign key check to 0 to temporarily disable foreign key constraints
                $disableForeignKeyCheckQuery = "SET foreign_key_checks = 0";
                mysqli_query($connection, $disableForeignKeyCheckQuery);
    
                $query = "DELETE FROM student_info WHERE student_ID=?"; // Using prepared statement
                $stmt = mysqli_prepare($connection, $query);
    
                // Bind parameter to the prepared statement
                mysqli_stmt_bind_param($stmt, "s", $studentID);
    
                // Execute the prepared statement
                if (mysqli_stmt_execute($stmt)) {
                    echo "Student deleted successfully";
                } else {
                    echo "Error deleting student: " . mysqli_error($connection);
                }
    
                // Enable foreign key check back to 1
                $enableForeignKeyCheckQuery = "SET foreign_key_checks = 1";
                mysqli_query($connection, $enableForeignKeyCheckQuery);
    
                mysqli_stmt_close($stmt);
                break;
    
            default:
                echo "Invalid action";
        }
    
        mysqli_close($connection);
    } else {
        echo "Error: Invalid request";
    }
?>
