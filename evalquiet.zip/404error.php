<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>404 - Page Not Found</title>
</head>
<body>
    <h1>404 - Page Not Found</h1>
    <p>The requested URL was not found on this server.</p>
    <p>Please check the URL or <a href="index.php">go to the homepage</a>.</p>
</body>
</html>
