
<?php
session_start(); // Start the session

// Check if session variables are set, indicating that the user is already logged in
if(isset($_SESSION['student_id']) && isset($_SESSION['course'])) {
    // Destroy the session variables
    session_unset();
    session_destroy();
}

$host = 'localhost';  
$dbname = 'evaluation_quiet';
$user = 'admin'; 
$pass = 'admin'; 

$errorMessage = ""; 

if (isset($_GET['error'])) {
  $errorMessage = $_GET['error'];
}

try {
  $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
  echo "Error: " . $e->getMessage();
  die(); 
}
// Function to check if there is an active session for a given student ID and course
function isSessionActive($pdo, $studentId, $course) {
    $stmt = $pdo->prepare("SELECT * FROM active_sessions WHERE user_id = :studentId AND course = :course");
    $stmt->bindParam(':studentId', $studentId);
    $stmt->bindParam(':course', $course);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC) !== false;
}
function studentAndCourseExist($pdo, $student_ID, $course) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM student_info WHERE student_ID = :studentId AND student_COURSE = :course");
    $stmt->bindParam(':studentId', $student_ID);
    $stmt->bindParam(':course', $course);
    $stmt->execute();
    $count = $stmt->fetchColumn();
    return $count > 0;
  }
  
// Check if the submitted student ID and course exist in the database
if (isset($_GET['studentId']) && isset($_GET['course'])) {
    $studentId = $_GET['studentId'];
    $course = $_GET['course'];

    if (studentAndCourseExist($pdo, $studentId, $course)) {
        // Check if there is an active session for the provided student ID and course
        if (isSessionActive($pdo, $studentId, $course)) {
            $errorMessage = "There is already an active session for this student ID and course.";
        } else {
            // Store the student ID and course in session
            $_SESSION['student_id'] = $studentId;
            $_SESSION['course'] = $course;

            // Insert a new row into the active_sessions table
            $stmt = $pdo->prepare("INSERT INTO active_sessions (session_id, user_id, course) VALUES (:sessionId, :studentId, :course)");
            $stmt->bindParam(':sessionId', session_id());
            $stmt->bindParam(':studentId', $studentId);
            $stmt->bindParam(':course', $course);
            $stmt->execute();
            

            // Redirect to evaluation.php
            header("Location: evaluation.php?studentId=$studentId&course=$course");
            exit();
        }
    } else {
        // Student ID or course doesn't exist or not match from database
        $errorMessage = "Invalid student ID or course selected.";
    }
    // Check if the submitted student ID and course exist in the database

}
?>
<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css"/>
    <meta name="viewport" content="width=device-width, initial-scale=0.5">
    <style>
        body {
            margin: 0;
            padding: 0;
            height: 100vh;
            overflow: hidden;
            position: relative;
            font-family: Arial, sans-serif;
        }

        .background {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-image: url('exact_school_front.png');
            background-size: cover;
            background-position: center;
            filter: blur(3px); 
            z-index: 0;
        }

        .overlay-box {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: linear-gradient(to bottom, rgba(0, 0, 0, 0.7), rgba(0, 0, 0, 0.9));
            padding: 20px;
            color: white;
            border-radius: 10px;
            text-align: center;
            z-index: 1;
            width: 500px;
            max-width: 50%;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.5); /* Add a subtle box shadow */
        }

        .overlay-heading {
            font-size: 3rem;
            color: white;
            margin-top: 40px;
            font-weight: bold;
        }

        .form-container {
            margin-top: 40px;
        }

        .form-container label,
        .form-container input {
            margin-bottom: 20px;
        }

        .form-container button {
            padding: 10px 20px;
            background-color: #002afc;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        .form-container button:hover {
            background-color: #001f80;
        }

        .logo {
            position: absolute;
            top: -150px;
            left: 50%;
            transform: translateX(-50%);
            width: 150px;
            height: 150px;
            z-index: 2;
        }

        input[type=number]::-webkit-inner-spin-button,
        input[type=number]::-webkit-outer-spin-button {
            -webkit-appearance: none;
            margin: 0;
        }

        .disabled-button {
            box-shadow: none;
        }
        .secretbutton .secret-button{
            margin-right:300%;
            z-index: 1;
            color: rgba(0, 0, 0, 0.1);
        }
        .secretbutton .secret-button:hover{
            cursor: default;
            
        }
    </style>
</head>
<body>
  
<div class="background"></div>
<div class="overlay-box">
  
  
    <div class="evaluation">
        <img src="exact logo.png" alt="Logo" class="logo">
        <div class="overlay-box2">
        <div class="secretbutton">
<a href='../admin/admin_login.php' class='secret-button'>hi</a>
</div>
            <h2 class="overlay-heading">Faculty Evaluation</h2>
        </div>
        <p>Please input your student ID and Course to proceed to evaluation.</p>
        <div class="form-container">
        <form method="get" action="">

                <label for="studentId"><i class="fas fa-user-cog"></i> Student ID:</label>
                <input type="text" id="studentId" name="studentId" placeholder="YYYY-NNNNNN" maxlength="11" required><br>
                <label for="course"><i class="fas fa-user-cog"></i> Course:</label>
                <select id="course" name="course" required>
                    <option value="">Select Course</option>
                    <option value="BSIS">BSIS</option>
                    <option value="BSIT">BSIT</option>
                    <option value="BSTM">BSTM</option>
                    <option value="BSMA">BSMA</option>
                </select>
               
                <button type="submit" id="submitForm">Log In</button>
                <?php if (!empty($errorMessage)): ?>
                <p style="color: red;"><?php echo $errorMessage; ?></p>
                <?php endif; ?>
            </form>
            <p id="errorMessage" style="color: red;"></p>
        </div>
    </div>

</div>

<script>
    document.addEventListener("DOMContentLoaded", function() {
        var studentIdInput = document.getElementById("studentId");
        var studentCourseInput = document.getElementById("course"); // Fixed the name here
        var submitFormButton = document.getElementById("submitForm");
        var errorMessage = document.getElementById("errorMessage");

       
        submitFormButton.disabled = true;
        submitFormButton.classList.add("disabled-button");

        studentIdInput.addEventListener("blur", function(event) {
    var studentId = studentIdInput.value.trim();
    var format = /^([0-9]{2}[0-9]{2})-(\d{6})$/; // for the format "YYYY-NNNNNN"

    if (format.test(studentId)) {
        errorMessage.innerText = ""; // Clear the previous error message
        submitFormButton.disabled = false; // Enables the submit button
        submitFormButton.classList.remove("disabled-button"); // Add glowing effect
        
        // Remove the following line to prevent automatic course filling
        // fetchStudentCourse(studentId);
    } else {
        errorMessage.innerText = "Invalid student ID format. Please enter in the format YYYY-NNNNNN";
        submitFormButton.disabled = true; 
        submitFormButton.classList.add("disabled-button"); 
        studentCourseInput.value = "";
    }
});
        studentIdInput.addEventListener("input", function(event) {
            if (studentIdInput.value.trim() === "") {
                studentCourseInput.value = "";
                errorMessage.innerText = ""; // Clear error message when input is cleared
                submitFormButton.disabled = true; // Disable submit button
                submitFormButton.classList.add("disabled-button");
            }
        });
    });

    function fetchStudentCourse(studentId) {
    var xhr = new XMLHttpRequest();
    xhr.onreadystatechange = function() {
        if (xhr.readyState === XMLHttpRequest.DONE) {
            if (xhr.status === 200) {
                var response = JSON.parse(xhr.responseText); 
                var studentCourse = response.student_COURSE; 
                // Set the fetched student course in the studentCourse input field
                document.getElementById("course").value = studentCourse; // Fixed the name here
            } else {
                console.error('Error fetching student course:', xhr.status);
            }
        }
    };
    xhr.open('GET', 'fetch_student_details.php?studentId=' + encodeURIComponent(studentId), true);
    xhr.send();
}
</script>
</body>
</html>
