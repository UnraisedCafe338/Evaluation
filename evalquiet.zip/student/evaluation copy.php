<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<meta name="viewport" content="width=device-width, initial-scale=0.5">
<title>Evaluation Form</title>
<style>
  .top-bar {
    background: linear-gradient(to bottom, rgb(66, 78, 255), rgb(49, 0, 208));
    color: white; 
    padding: 30px 30px;
    height: 100px;

  }
  .top-bar::after {
    content: "";
    position: fixed;
    left: 50%;
    top: 100px;
    transform: translateX(-50%) translateY(-50%);
    width: 3000px;
    height: 5px;
    background-color: darkgoldenrod;
    margin-bottom: 100px;
    
  }
  .below-bar {
    background: white;
    color: black; 
    padding: 10px 10px;
    height: 35px; 
  }
  .background {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-image: url('#');
    background-size: cover;
    background-position: center;
    background-color: darkblue;
    filter: blur(5px); 
    z-index: -1;
  }
  b {
    display: inline-block; 
    width: 300px; 
  }
  .ratings-group {
    padding-left: 1000px;
    color: white;
  }
  .questions-group {
    padding-left: 20px; 
    color: white;
    display: inline-block; 
    vertical-align: top; 
  }
  .teacher-button {
    padding: 10px;
    margin: 5px;
    background: linear-gradient(to bottom, rgb(66, 78, 255), rgb(49, 0, 208));
    color: white;
    border: none;
    cursor: pointer;
    border-top-right-radius: 10px;
    border-top-left-radius: 10px;
    width: 150px; 
    display: inline-block; 
    text-align: center; 
  }
  .teacher-button:hover {
    background-color: #0025a7; 
    color: #f0e817;
  }
  .selected-teacher {
    background: #001f7c; 
  }
  .teacher-info {
    color: white;
  }
  .table-container {
    display: none; 
    width: 100%;
  }
  .table {
    border-collapse: separate;
    border-spacing: 5;
    width: 100%; 
    border-radius: 0px;
    top: 100px;
    padding-top: 10px;
    background-color: blue;
    color: #002bc2; 
    height: 200%;
  }
  th, td {
    padding: 10px;
    text-align: left;
    border: 1px solid #002bc2; 
    width: auto;
  }
  .evaluated-success{
    font-size: larger;
    font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;
    color: green;
  }
</style>
</head>
<body>
<header class="top-bar">
  <h1>Evaluation Form</h1>
</header>

<div class="background"></div>

<form id="evaluationForm" method="post" action="student_login.php" onsubmit="return calculateTotalScore(event)">


<?php
session_start(); // Start the session

$host = 'localhost';  
$dbname = 'evaluation_quiet';
$user = 'admin'; 
$pass = 'admin'; 

$errorMessage = ""; 

if (isset($_GET['error'])) {
  $errorMessage = $_GET['error'];
}

try {
  $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
  echo "Error: " . $e->getMessage();
  die(); 
}

// Check if the student ID from the session matches the student ID provided in the URL parameters
if(isset($_SESSION['student_id']) && isset($_GET['studentId']) && $_SESSION['student_id'] !== $_GET['studentId']) {
  // Redirect the user to the login page if the session student ID does not match the provided student ID
  header("Location: student_login.php");
  exit(); 
}

function isUserAlreadyLoggedIn($pdo, $studentId) {
    $stmt = $pdo->prepare("SELECT * FROM active_sessions WHERE user_id = :studentId");
    $stmt->bindParam(':studentId', $studentId);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

// Check if the submitted student ID is already logged in
if (isset($_GET['studentId'])) {
    $studentId = $_GET['studentId'];

    if (isUserAlreadyLoggedIn($pdo, $studentId)) {
        $errorMessage = "Student ID is already logged in.";
    } else {
        
        $_SESSION['student_id'] = $studentId;

        
        $stmt = $pdo->prepare("INSERT INTO active_sessions (session_id, user_id) VALUES (:sessionId, :studentId)");
        $stmt->bindParam(':sessionId', session_id());
        $stmt->bindParam(':studentId', $studentId);
        $stmt->execute();

        header("Location: evaluation.php");
        exit();
    }
}
if(isset($_SESSION['student_id'])) {
  $student_id = $_SESSION['student_id'];

  $stmt_remove_session = $pdo->prepare("DELETE FROM active_sessions WHERE user_id = :student_id");
  $stmt_remove_session->bindValue(':student_id', $student_id, PDO::PARAM_STR);
  $stmt_remove_session->execute();

  $stmt_insert_session = $pdo->prepare("INSERT INTO active_sessions (session_id, user_id) VALUES (:session_id, :student_id)");
$stmt_insert_session->bindValue(':session_id', session_id(), PDO::PARAM_STR);
$stmt_insert_session->bindValue(':student_id', $student_id, PDO::PARAM_STR);
$stmt_insert_session->execute();

}

if(isset($_POST['logout'])) {
  
  unset($_SESSION['student_id']);
  unset($_SESSION['course']);

  header("Location: student_login.php");
  exit(); 
}

try {
  $pdo = new PDO("mysql:host=$host;dbname=$dbname", $user, $pass);
  $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

  $loggedInStudentID = $_GET['studentId'];
  $stmt_studentID = $pdo->prepare("SELECT StudentID FROM student_info WHERE student_ID = :student_ID");
  $stmt_studentID->bindParam(':student_ID', $loggedInStudentID);
  $stmt_studentID->execute();
  $studentIDRow = $stmt_studentID->fetch(PDO::FETCH_ASSOC);
  $student_ID = $studentIDRow['StudentID'];

  if (isset($_GET['studentId'])) {
    
      $stmt_student_info = $pdo->prepare("SELECT student_NAME, student_ID, student_SECTION, student_COURSE FROM student_info WHERE StudentID = :student_ID");
      $stmt_student_info->bindParam(':student_ID', $student_ID);
      $stmt_student_info->execute();
      $studentInfo = $stmt_student_info->fetch(PDO::FETCH_ASSOC);

      // Display the student informations of the student logged in based from student id
      if ($studentInfo) {
          echo "<div class='below-bar'>⇛ Student Name: " . $studentInfo['student_NAME'] . "</div>";
          echo "<div class='below-bar'>⇛ Student ID: " . $studentInfo['student_ID'] . "</div>";
          echo "<div class='below-bar'>⇛ Student Course: " . $studentInfo['student_COURSE'] . "-" . $studentInfo['student_SECTION'] . "</div>";

          // Get the faculty members based on the subjects taught to the student, except those already evaluated
          $stmt = $pdo->prepare("
          SELECT facultymembers.Name
          FROM enrollments
          INNER JOIN subjects ON enrollments.SubjectID = subjects.SubjectID
          INNER JOIN facultymembers ON subjects.FacultyID = facultymembers.FacultyID
          WHERE enrollments.StudentID = :student_ID
          AND facultymembers.Name NOT IN (
              SELECT DISTINCT teacher FROM evaluation_table WHERE StudentID = :student_ID
          )
      ");
      $stmt->bindParam(':student_ID', $student_ID);
      $stmt->execute();
      $teachersToEvaluate = $stmt->fetchAll(PDO::FETCH_ASSOC);
      $uniqueTeachers = array();
      if ($teachersToEvaluate) {
        // Prevent the duplicated teacher buttons with same name
        echo "<div class='below-bar'>Teachers to Evaluate:</div>";
        $uniqueTeachers = array();
        
        
        foreach ($teachersToEvaluate as $teacher) {
            // Add the teacher to the unique teachers array if not already show
            if (!in_array($teacher['Name'], $uniqueTeachers)) {
                $uniqueTeachers[] = $teacher['Name'];
                echo '<button class="teacher-button" type="button" onclick="evaluateTeacher(\'' . $teacher['Name'] . '\', this)">' . $teacher['Name'] . '</button>';
            }
        }
    } else {
        // Display message if all teachers have been evaluated
        echo "<div class='below-bar'><p class='evaluated-success'>All Teachers have been successfully evaluated.</p></div>";
    }

    $numTotalTeachers = count($uniqueTeachers);
    
    $stmtTeachersEvaluated = $pdo->prepare("SELECT COUNT(DISTINCT teacher) AS num_teachers_evaluated FROM evaluation_table WHERE student_ID = :student_ID");
    $stmtTeachersEvaluated->bindParam(':student_ID', $student_ID);
    $stmtTeachersEvaluated->execute();
    $numTeachersEvaluatedRow = $stmtTeachersEvaluated->fetch(PDO::FETCH_ASSOC);
    $numTeachersEvaluated = $numTeachersEvaluatedRow['num_teachers_evaluated'];
    
    // TESTER: Display the number of teachers evaluated and the total number of teachers
    //echo "Number of teachers evaluated: " . $numTeachersEvaluated . "<br>";
    //echo "Total number of teachers: " . $numTotalTeachers . "<br>";
 
    if ($numTeachersEvaluated >= $numTotalTeachers) {
        echo '<button id="logoutBtn" class="btn btn-danger" onclick="backToLoginPage()">Log Out</button>';
    } else {
        echo '<button id="submitEvaluationBtn" class="btn btn-primary" type="submit" onclick="reloadPage()">Submit Evaluation</button>';
    }
    
    



          
      } else {
          echo "Student information not found.";
      }
  } else {
      echo "Student ID not provided in the URL parameters.";
  }



} catch (PDOException $e) {

  echo "Connection failed: " . $e->getMessage();
}


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  try {
 
      $data = json_decode(file_get_contents('php://input'), true);
      $teacher = $data['teacher'];
      $totalScore = $data['totalScore'];
      $ratings = $data['ratings'];
      $studentId = $loggedInStudentID; // Use the logged-in student ID retrieved earlier

      // Insert the evaluation data into the database
      $stmt = $pdo->prepare("INSERT INTO evaluation_table (student_ID, StudentID, teacher, total_score, ratings) VALUES (:studentId, :StudentID, :teacher, :totalScore, :ratings)");
      $stmt->bindParam(':studentId', $studentId);
      $stmt->bindParam(':StudentID', $student_ID); // Bind StudentID to the retrieved student_ID
      $stmt->bindParam(':teacher', $teacher);
      $stmt->bindParam(':totalScore', $totalScore);
      $stmt->bindParam(':ratings', json_encode($ratings));
      $stmt->execute();

      echo 'Evaluation submitted successfully.';
  } catch (PDOException $e) {
      echo 'Error: Failed to submit evaluation. Please try again later.';
      echo "Error Message: " . $e->getMessage();
  }
}
foreach ($teachersToEvaluate as $teacher) {
  if (!in_array($teacher['Name'], $uniqueTeachers)) {
      $uniqueTeachers[] = $teacher['Name'];
      echo '<button class="teacher-button" type="button" onclick="evaluateTeacher(\'' . $teacher['Name'] . '\', this)">' . $teacher['Name'] . '</button>';
  }
}
// Check if there are no teachers left to evaluate
if (!$teachersToEvaluate) {
  // Call the function to display "Done evaluating" message
  echo '<script>showDoneEvaluatingMessage();</script>';
}

?>

<input type="hidden" id="selectedTeacher" name="selectedTeacher">
<div class="table-container" id="tableContainer">
  <table class="table" id="evaluationTable">
    
  </table>
</div>


</form>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
<script>
// Function to evaluate a teacher
function evaluateTeacher(teacherName, button) {
    // Check if the teacher has already been evaluated
    var evaluatedTeachers = JSON.parse(localStorage.getItem('evaluatedTeachers')) || {};
    if (evaluatedTeachers[teacherName]) {
        alert("You've already evaluated this teacher.");
        return;
    }

    // Update the evaluation form with the selected teacher
    document.getElementById('selectedTeacher').value = teacherName;
    var newEvaluationForm = '<p class="teacher-info">Selected Teacher: ' + teacherName + '</p>';

    // Get the questions from the database
    fetch('get_questions.php') 
        .then(response => response.json())
        .then(questions => {
            // Generate HTML for the questionnaire based on retrieved questions from database
            var newEvaluationTable = '<tr class="blue-row"><th>Questions</th><th>Ratings</th></tr>';
            questions.forEach(question => {
                newEvaluationTable += '<tr class="yellow-row"><td>' + question.question_text + '</td><td>';
                newEvaluationTable += '<input type="radio" id="rating5" name="rating[' + question.question_id + ']" value="5" required onclick="storeRatings(this)">';
                newEvaluationTable += '<label for="rating5">5 &nbsp;&nbsp;&nbsp;</label>';
                newEvaluationTable += '<input type="radio" id="rating4" name="rating[' + question.question_id + ']" value="4" onclick="storeRatings(this)">';
                newEvaluationTable += '<label for="rating4"> 4 &nbsp;&nbsp;&nbsp; </label>';
                newEvaluationTable += '<input type="radio" id="rating3" name="rating[' + question.question_id + ']" value="3" onclick="storeRatings(this)">';
                newEvaluationTable += '<label for="rating3"> 3 &nbsp;&nbsp;&nbsp; </label>';
                newEvaluationTable += '<input type="radio" id="rating2" name="rating[' + question.question_id + ']" value="2" onclick="storeRatings(this)">';
                newEvaluationTable += '<label for="rating2"> 2 &nbsp;&nbsp;&nbsp; </label>';
                newEvaluationTable += '<input type="radio" id="rating1" name="rating[' + question.question_id + ']" value="1" onclick="storeRatings(this)">';
                newEvaluationTable += '<label for="rating1"> 1 </label></td></tr>';
            });
            document.getElementById('evaluationTable').innerHTML = newEvaluationTable;
            document.getElementById('tableContainer').style.display = 'block';
            button.classList.add('selected-teacher');
            var buttons = document.querySelectorAll('.teacher-button');
            buttons.forEach(function(b) {
                if (b !== button) {
                    b.classList.remove('selected-teacher');
                }
            });
            loadRatings();
        })
        .catch(error => {
            console.error('Error fetching questions:', error);
        });
}
function storeRatings(radio) {
  var selectedTeacher = document.getElementById('selectedTeacher').value;
  var groupId = radio.getAttribute('name');
  var ratingValue = parseInt(radio.value);
  
  var storedRatings = JSON.parse(localStorage.getItem('storedRatings')) || {};
  storedRatings[selectedTeacher] = storedRatings[selectedTeacher] || {};
  storedRatings[selectedTeacher][groupId] = ratingValue;
  localStorage.setItem('storedRatings', JSON.stringify(storedRatings));

 
  var submitButton = document.querySelector('button[type="submit"]');
  submitButton.disabled = false;
}

// load the saved ratings from local storage of the browser
function loadRatings() {
  var selectedTeacher = document.getElementById('selectedTeacher').value;
  var storedRatings = JSON.parse(localStorage.getItem('storedRatings')) || {};
  var ratings = storedRatings[selectedTeacher] || {};

  
  for (var groupId in ratings) {
    var ratingValue = ratings[groupId];
    var radio = document.querySelector('input[name="' + groupId + '"][value="' + ratingValue + '"]');
    if (radio) {
      radio.checked = true;
    }
  }
}
// calculate total score average of ratings
function calculateTotalScore(event) {
    
    event.preventDefault();

    // Disable the submit button to prevent multiple submissions by the user
    var submitButton = document.querySelector('button[type="submit"]');
    submitButton.disabled = true;

    // hides the selected teacher button and the evaluation 
    var selectedTeacherButton = document.querySelector('.selected-teacher');
    selectedTeacherButton.remove();
    document.getElementById('tableContainer').style.display = 'none';

    var totalScore = 0;
    var numRatingGroups = 0;

    for (var groupId = 1; groupId <= 5; groupId++) {
        var ratingInput = document.querySelector('input[name="rating[' + groupId + ']"]:checked');
        if (ratingInput) {
            totalScore += parseInt(ratingInput.value);
            numRatingGroups++;
        }
    }

    // Calculate the average score of the rating
    if (numRatingGroups > 0) {
        totalScore /= numRatingGroups;
    }

    var formData = {
        teacher: document.getElementById('selectedTeacher').value,
        totalScore: totalScore,
        ratings: JSON.parse(localStorage.getItem('storedRatings'))[document.getElementById('selectedTeacher').value] // Retrieve ratings from localStorage
    };

    fetch(window.location.href, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(formData)
    })
    .then(response => {
        if (response.ok) {
            // Remove the saved ratings for the current teacher from local storage in the browser
            var storedRatings = JSON.parse(localStorage.getItem('storedRatings')) || {};
            delete storedRatings[formData.teacher];
            localStorage.setItem('storedRatings', JSON.stringify(storedRatings));
            var numTeachers = <?php echo $numTotalTeachers; ?>;
            var numEvaluated = <?php echo $numTeachersEvaluated; ?>;
            if (numEvaluated >= numTeachers) {
                document.getElementById('backToLoginBtn').style.display = 'block';
            }
            if (document.querySelectorAll('.teacher-button').length === 1) {
                setTimeout(function() {
                    location.reload();
                }, 10); 
            }

            // Display success submit message with check animation
            var successMessage = document.createElement('div');
            successMessage.classList.add('success-message');
            successMessage.innerHTML = '<svg viewBox="0 0 24 24" fill="green" width="48px" height="48px"><path d="M0 0h24v24H0z" fill="none"/><path d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z"/></svg>';
            successMessage.innerHTML += '<p style="color: yellow">Evaluation submitted successfully for ' + formData.teacher + '.</p>';
            document.body.appendChild(successMessage);
            setTimeout(function() {
                successMessage.remove();
            }, 5000);

            return response.text();
        }
        throw new Error('Network response was not ok.');
    })
    .then(data => {
        document.getElementById('submitStatus').innerHTML = data;
    })
    .catch(error => {
        console.error('Error:', error);
        document.getElementById('submitStatus').innerText = 'Error: Failed to submit evaluation. Please try again later.';
    });
    submitButton.disabled = true;

    return false;
}
function backToLoginPage() {
    // Perform an AJAX request to remove the session
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'remove_session.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.send();

    // Redirect to the login page after removing the session
    window.location.href = 'student_login.php'; 
}

function reloadPage() {
    if (document.querySelectorAll('.teacher-button').length === 1) {
        setTimeout(function() {
            location.reload();
        }, 10); 
    } else {
        
        console.log("All teachers have not been evaluated yet.");
    }
}
function showDoneEvaluatingMessage() {
    var messageContainer = document.createElement('div');
    messageContainer.classList.add('done-evaluating-message');
    messageContainer.innerText = 'Done evaluating';
    document.body.appendChild(messageContainer);

    setTimeout(function() {
        messageContainer.remove();
    }, 5000);
}

</script>

</body>

</html>
