-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 02, 2024 at 04:05 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `evaluation_quiet`
--

-- --------------------------------------------------------

--
-- Table structure for table `academic_list`
--

CREATE TABLE `academic_list` (
  `id` int(30) NOT NULL,
  `year` text NOT NULL,
  `semester` int(1) NOT NULL,
  `default_select` tinyint(1) NOT NULL,
  `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `academic_list`
--

INSERT INTO `academic_list` (`id`, `year`, `semester`, `default_select`, `status`) VALUES
(11, '2023-2024', 1, 0, 0),
(12, '2025-2026', 2, 0, 0),
(13, '2024-2025', 1, 0, 0),
(14, '202', 1, 0, 0),
(15, '2023-2025', 2, 0, 0),
(16, '2023-2024', 1, 0, 0),
(17, '2023-2024', 1, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `active_sessions`
--

CREATE TABLE `active_sessions` (
  `id` int(11) NOT NULL,
  `user_id` varchar(11) DEFAULT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  `login_time` timestamp NOT NULL DEFAULT current_timestamp(),
  `course` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `active_sessions`
--

INSERT INTO `active_sessions` (`id`, `user_id`, `session_id`, `login_time`, `course`) VALUES
(406, '2020-123456', 'aekhomjnkd273ch475s5cv1k5p', '2024-04-24 12:27:33', NULL),
(407, '2020-123456', '', '2024-04-24 12:27:37', 'BSIS'),
(455, '2020-003830', '8fa2fij6eluog30iq7nqb5dtoh', '2024-04-25 04:23:22', NULL),
(472, '2020-123458', '68ei831dqcvpj63el55jndec2g', '2024-04-29 05:26:21', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `admin_list`
--

CREATE TABLE `admin_list` (
  `admin_ID` int(11) NOT NULL,
  `admin_name` varchar(50) NOT NULL,
  `admin_pass` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admin_list`
--

INSERT INTO `admin_list` (`admin_ID`, `admin_name`, `admin_pass`) VALUES
(1, 'admin', 'admin'),
(2, 'admin1', 'admin1');

-- --------------------------------------------------------

--
-- Table structure for table `criteria`
--

CREATE TABLE `criteria` (
  `criteria_id` int(11) NOT NULL,
  `criteria_name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `criteria`
--

INSERT INTO `criteria` (`criteria_id`, `criteria_name`) VALUES
(1, 'COMMUNICATION SKILLS'),
(2, 'INSTRUCTION SKILLS'),
(3, 'KNOWLEDGE OF THE SUBJECT MATTER');

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `dep_id` int(11) NOT NULL,
  `dep_name` varchar(100) NOT NULL,
  `dep_code` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `enrollments`
--

CREATE TABLE `enrollments` (
  `EnrollmentID` int(11) NOT NULL,
  `StudentID` int(11) DEFAULT NULL,
  `SubjectID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `enrollments`
--

INSERT INTO `enrollments` (`EnrollmentID`, `StudentID`, `SubjectID`) VALUES
(1, 1, 4),
(2, 2, 2),
(3, 3, 3),
(4, 1, 8),
(5, 1, 9),
(6, 1, 6),
(7, 2, 202),
(8, 2, 10);

-- --------------------------------------------------------

--
-- Table structure for table `evaluation_summary`
--

CREATE TABLE `evaluation_summary` (
  `summary_id` int(11) NOT NULL,
  `faculty_id` int(11) NOT NULL,
  `semester` varchar(20) NOT NULL,
  `avg_rating` decimal(3,2) NOT NULL,
  `num_evaluators` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `evaluation_table`
--

CREATE TABLE `evaluation_table` (
  `evaluation_id` int(11) NOT NULL,
  `teacher` varchar(100) NOT NULL,
  `total_score` float(5,2) NOT NULL,
  `ratings` text NOT NULL,
  `student_ID` varchar(11) NOT NULL,
  `StudentID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `facultymembers`
--

CREATE TABLE `facultymembers` (
  `FacultyID` int(11) NOT NULL,
  `Name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `facultymembers`
--

INSERT INTO `facultymembers` (`FacultyID`, `Name`) VALUES
(101, 'Professor Brown'),
(102, 'Professor Green'),
(201, 'Prof. Smith'),
(202, 'Prof. Johnson'),
(203, 'Prof. Brown'),
(204, 'Prof. Wilson'),
(205, 'Prof. Lee'),
(206, 'Prof. Garcia'),
(207, 'Prof. Martinez'),
(208, 'Prof. Anderson'),
(209, 'Prof. Taylor'),
(210, 'Prof. Thomas');

-- --------------------------------------------------------

--
-- Table structure for table `question_list`
--

CREATE TABLE `question_list` (
  `question_id` int(11) NOT NULL,
  `question_text` varchar(100) NOT NULL,
  `criteria_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `question_list`
--

INSERT INTO `question_list` (`question_id`, `question_text`, `criteria_id`) VALUES
(1, 'Was good at explaining things', 1),
(2, 'Was well prepared', 1),
(3, 'How satisfied are you with your overall job role and responsibilities?', 1),
(4, 'How would you rate the level of support you receive from your immediate supervisor or manager?', 1),
(5, 'How effective is communication within your team or department?', 1),
(6, 'To what extent do you feel your skills and expertise are utilized in your current role?', 2),
(7, 'How satisfied are you with the opportunities for professional development and growth within the orga', 2),
(8, 'How would you rate the work-life balance offered by the company?', 2),
(9, '', 3),
(10, 'How satisfied are you with the physical work environment (e.g., office space, facilities)?', 3),
(11, 'How well do you feel your contributions are recognized and appreciated by your colleagues and superi', 3),
(12, 'How would you rate the level of collaboration and teamwork within your department?', 3),
(13, 'How satisfied are you with the company\'s benefits package (e.g., health insurance, retirement plans)', 1),
(14, 'How would you rate the organization\'s commitment to diversity and inclusion?', 2),
(15, 'How satisfied are you with the performance appraisal process and feedback provided?', 3),
(16, 'How effectively do you feel conflicts or issues are resolved within the team or organization?', 1),
(17, 'Was receiptive to students\' questions', 2),
(18, 'Was good at explaining things', 2);

-- --------------------------------------------------------

--
-- Table structure for table `student_info`
--

CREATE TABLE `student_info` (
  `id` int(11) NOT NULL,
  `student_ID` varchar(11) NOT NULL,
  `student_NAME` varchar(30) NOT NULL,
  `student_COURSE` varchar(20) DEFAULT NULL,
  `student_SECTION` varchar(20) NOT NULL,
  `evaluated` tinyint(1) NOT NULL,
  `regular_student` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `student_info`
--

INSERT INTO `student_info` (`id`, `student_ID`, `student_NAME`, `student_COURSE`, `student_SECTION`, `evaluated`, `regular_student`) VALUES
(1, '2020-123459', 'Naruto', 'BSTM', 'Prova2', 0, 0),
(3, '2020-123457', 'test', 'BSIS', 'Prova', 0, 0),
(4, '1', 'zean ', 'bsis', 'prova', 0, 0),
(6, '2020-123456', 'bngf', 'fgf', 'Prova', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `subjects`
--

CREATE TABLE `subjects` (
  `SubjectID` int(11) NOT NULL,
  `Name` varchar(100) DEFAULT NULL,
  `subject_code` varchar(30) NOT NULL,
  `FacultyID` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `subjects`
--

INSERT INTO `subjects` (`SubjectID`, `Name`, `subject_code`, `FacultyID`) VALUES
(1, 'Mathematics', 'MT01', 201),
(2, 'Physics', 'P01', 202),
(3, 'Biology', 'B01', 203),
(4, 'Chemistry', 'C01', 202),
(5, 'History', 'H01', 201),
(6, 'Computer Science', '0', 204),
(7, 'Literature', '0', 203),
(8, 'Geography', '0', 201),
(9, 'Economics', '0', 202),
(10, 'Psychology', '0', 204),
(11, 'Mathematics', '0', 101),
(202, 'English', '0', 102);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `academic_list`
--
ALTER TABLE `academic_list`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `active_sessions`
--
ALTER TABLE `active_sessions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `admin_list`
--
ALTER TABLE `admin_list`
  ADD PRIMARY KEY (`admin_ID`);

--
-- Indexes for table `criteria`
--
ALTER TABLE `criteria`
  ADD PRIMARY KEY (`criteria_id`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD PRIMARY KEY (`dep_id`);

--
-- Indexes for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD PRIMARY KEY (`EnrollmentID`),
  ADD KEY `fk_student_info_student_id` (`StudentID`),
  ADD KEY `fk_student_info_subject_id` (`SubjectID`);

--
-- Indexes for table `evaluation_summary`
--
ALTER TABLE `evaluation_summary`
  ADD PRIMARY KEY (`summary_id`);

--
-- Indexes for table `evaluation_table`
--
ALTER TABLE `evaluation_table`
  ADD PRIMARY KEY (`evaluation_id`),
  ADD KEY `StudentID` (`StudentID`);

--
-- Indexes for table `facultymembers`
--
ALTER TABLE `facultymembers`
  ADD PRIMARY KEY (`FacultyID`);

--
-- Indexes for table `question_list`
--
ALTER TABLE `question_list`
  ADD PRIMARY KEY (`question_id`);

--
-- Indexes for table `student_info`
--
ALTER TABLE `student_info`
  ADD UNIQUE KEY `StudentID` (`id`);

--
-- Indexes for table `subjects`
--
ALTER TABLE `subjects`
  ADD PRIMARY KEY (`SubjectID`),
  ADD KEY `FacultyID` (`FacultyID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `academic_list`
--
ALTER TABLE `academic_list`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `active_sessions`
--
ALTER TABLE `active_sessions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=473;

--
-- AUTO_INCREMENT for table `admin_list`
--
ALTER TABLE `admin_list`
  MODIFY `admin_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `criteria`
--
ALTER TABLE `criteria`
  MODIFY `criteria_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `dep_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `evaluation_summary`
--
ALTER TABLE `evaluation_summary`
  MODIFY `summary_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `evaluation_table`
--
ALTER TABLE `evaluation_table`
  MODIFY `evaluation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=283;

--
-- AUTO_INCREMENT for table `question_list`
--
ALTER TABLE `question_list`
  MODIFY `question_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `student_info`
--
ALTER TABLE `student_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `enrollments`
--
ALTER TABLE `enrollments`
  ADD CONSTRAINT `fk_student_info_student_id` FOREIGN KEY (`StudentID`) REFERENCES `student_info` (`id`),
  ADD CONSTRAINT `fk_student_info_subject_id` FOREIGN KEY (`SubjectID`) REFERENCES `subjects` (`SubjectID`);

--
-- Constraints for table `evaluation_table`
--
ALTER TABLE `evaluation_table`
  ADD CONSTRAINT `evaluation_table_ibfk_1` FOREIGN KEY (`StudentID`) REFERENCES `student_info` (`id`);

--
-- Constraints for table `subjects`
--
ALTER TABLE `subjects`
  ADD CONSTRAINT `subjects_ibfk_1` FOREIGN KEY (`FacultyID`) REFERENCES `facultymembers` (`FacultyID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
